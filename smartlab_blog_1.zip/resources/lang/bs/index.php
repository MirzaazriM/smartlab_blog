<?php

return [

    'heading' => 'Glavna stranica'

];