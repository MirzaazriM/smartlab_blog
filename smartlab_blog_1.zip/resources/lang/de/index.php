<?php

return [

    'heading' => 'Erste Seite'

];