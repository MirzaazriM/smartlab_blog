<?php

return [

    'heading' => 'Main page'

];